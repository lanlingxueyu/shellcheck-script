This is a precompiled ShellCheck binary.
      https://www.shellcheck.net/

ShellCheck is a static analysis tool for shell scripts.
It's licensed under the GNU General Public License v3.0.
Information and source code is available on the website.

This binary was compiled on Mon Jul 29 01:33:38 UTC 2019.



      ====== Latest commits ======

commit b7b4d5d29e401858074b0d36d7bb53da58c3932d
Author: Vidar Holen <spam@vidarholen.net>
Date:   Sun Jul 28 17:45:01 2019 -0700

    Stable version 0.7.0
    
    This release is dedicated to RetroArch: the second best way to make your
    PC feel like a 16bit system (right after building ShellCheck with GHC)

commit 9cc9a575b274d081b59c5384dbab8112380aa9a6
Author: Vidar Holen <spam@vidarholen.net>
Date:   Sun Jul 28 18:12:11 2019 -0700

    Tweak man page

commit b2dd00e4ee7d74774932024924dbe34988d9ab6f
Author: Vidar Holen <spam@vidarholen.net>
Date:   Sun Jul 28 17:26:31 2019 -0700

    Mention aarch64 and macOS binaries in CHANGELOG
